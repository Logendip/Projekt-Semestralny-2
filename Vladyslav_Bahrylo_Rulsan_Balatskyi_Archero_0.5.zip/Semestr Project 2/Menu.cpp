#include "Classes.h"
#include "Menu.h"
#include "Settings.h"

void ensureGearFileExistsAndValid() {
    std::ifstream infile("gear.txt");
    bool valid = false;

    if (infile.is_open()) {
        std::string firstLine;
        if (std::getline(infile, firstLine)) {
            std::stringstream ss(firstLine);
            int value;
            if (ss >> value) {
                valid = true; // File exists and first value is an integer
            }
        }
        infile.close();
    }

    if (!valid) {
        std::ofstream outfile("gear.txt");
        if (outfile.is_open()) {
            outfile << "0\n0\n0\n";
            outfile.close();
            std::cout << "gear.txt was missing or invalid. Reset to default values.\n";
        }
        else {
            std::cerr << "Failed to create gear.txt\n";
        }
    }
}

void setupTriangles(sf::ConvexShape& leftTriangle, sf::ConvexShape& rightTriangle, const sf::RectangleShape& outlineSquare) {
    float outlineBottomY = outlineSquare.getPosition().y + outlineSquare.getSize().y / 2.f + 20.f;
    float centerX = outlineSquare.getPosition().x;

    leftTriangle.setPointCount(3);
    leftTriangle.setPoint(0, { 0.f, 20.f });
    leftTriangle.setPoint(1, { 20.f, 0.f });
    leftTriangle.setPoint(2, { 20.f, 40.f });
    leftTriangle.setFillColor(sf::Color::White);
    leftTriangle.setPosition({ centerX - 150.f, outlineBottomY });

    rightTriangle.setPointCount(3);
    rightTriangle.setPoint(0, { 0.f, 0.f });
    rightTriangle.setPoint(1, { 20.f, 20.f });
    rightTriangle.setPoint(2, { 0.f, 40.f });
    rightTriangle.setFillColor(sf::Color::White);
    rightTriangle.setPosition({ centerX + 150.f, outlineBottomY });
}

void setupSquares(sf::RectangleShape& swordSquare, sf::RectangleShape& shieldSquare, sf::RectangleShape& gearSquare, const sf::RectangleShape& outlineSquare) {
    const float squareSize = 100.f;
    const float margin = 10.f;

    swordSquare.setSize(sf::Vector2f(squareSize, squareSize));
    swordSquare.setPosition({
        outlineSquare.getPosition().x - squareSize / 2.f,
        outlineSquare.getPosition().y - outlineSquare.getSize().y / 2.f - squareSize - margin
        });

    shieldSquare.setSize(sf::Vector2f(squareSize, squareSize));
    shieldSquare.setPosition({
        outlineSquare.getPosition().x - outlineSquare.getSize().x / 2.f - squareSize - margin,
        outlineSquare.getPosition().y - squareSize / 2.f
        });

    gearSquare.setSize(sf::Vector2f(squareSize, squareSize));
    gearSquare.setPosition({
        outlineSquare.getPosition().x + outlineSquare.getSize().x / 2.f + margin,
        outlineSquare.getPosition().y - squareSize / 2.f
        });

    swordSquare.setFillColor(sf::Color(255, 255, 255, 128));
    shieldSquare.setFillColor(sf::Color(255, 255, 255, 128));
    gearSquare.setFillColor(sf::Color(255, 255, 255, 128));
}

void loadGearValues(int& swordValue, int& shieldValue, int& gearValue) {
    std::ifstream gearFile("gear.txt");
    if (!gearFile) {
        std::cerr << "Failed to open gear.txt\n";
        return;
    }
    std::string line;

    if (std::getline(gearFile, line)) {
        swordValue = std::stoi(line);
    }

    if (std::getline(gearFile, line)) {
        shieldValue = std::stoi(line);
    }

    if (std::getline(gearFile, line)) {
        gearValue = std::stoi(line);
    }
}



void mainMenu(sf::RenderWindow& window, Character& player) {
    std::string folder = "assets/Knight/";
    std::string add = "";
    int frameWidth = 80;
    int frameHeight = 80;

    sf::Texture settings("assets/UI/Settings.png");
    sf::Sprite settings_sprite(settings);

    window.setTitle("Game title");
    window.clear(sf::Color::White);
    sf::Sprite backgroundSprite(backgroundTexture);

    sf::Texture staticTexture;
    if (!staticTexture.loadFromFile("assets/Knight/Comparison2x.png")) {
        std::cerr << "Failed to load static texture.\n";
        return;
    }

    sf::Sprite staticSprite(staticTexture);
    staticSprite.setTextureRect({ {23, 0}, {frameWidth, frameHeight} });
    staticSprite.setScale({ 6.f, 6.f });

    sf::FloatRect bounds = staticSprite.getLocalBounds();
    staticSprite.setOrigin({ bounds.size.x / 2.f, bounds.size.y / 2.f });
    staticSprite.setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) / 2.f });

    settings_sprite.setTextureRect({ {296, 32}, {16, 16} });
    settings_sprite.setScale({ 4.f, 4.f });
    settings_sprite.setPosition({ 16, 16 });

    sf::RectangleShape outlineSquare;
    outlineSquare.setSize(sf::Vector2f(500.f, 500.f));
    outlineSquare.setFillColor(sf::Color::Transparent);
    outlineSquare.setOutlineThickness(3.f);
    outlineSquare.setOutlineColor(sf::Color::White);
    outlineSquare.setOrigin(outlineSquare.getSize() / 2.f);
    outlineSquare.setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) / 2.f });

    std::vector<std::string> options = { "Option 1", "Option 2", "Option 3", "Option 4" };
    std::vector<sf::Vector2i> optionOffsets = { {23, 0}, {23, 80}, {23 + 114, 0}, {23 + 112, 80} };
    int currentIndex = 0;

    sf::ConvexShape leftTriangle, rightTriangle;
    setupTriangles(leftTriangle, rightTriangle, outlineSquare);

    sf::Text optionText(font);
    optionText.setCharacterSize(30);
    optionText.setFillColor(sf::Color::White);
    optionText.setString(options[currentIndex]);
    optionText.setOrigin({ optionText.getLocalBounds().size.x / 2.f, 0.f });
    optionText.setPosition({ outlineSquare.getPosition().x, outlineSquare.getPosition().y + outlineSquare.getSize().y / 2.f + 25.f });

    auto updateOption = [&]() {
        optionText.setString(options[currentIndex]);
        optionText.setOrigin({ optionText.getLocalBounds().size.x / 2.f, 0.f });
        staticSprite.setTextureRect(sf::IntRect(optionOffsets[currentIndex], { frameWidth, frameHeight }));
        };

    sf::Text enterText(font);
    enterText.setString("Enter");
    enterText.setCharacterSize(50);
    enterText.setFillColor(sf::Color::White);
    enterText.setOrigin({ enterText.getLocalBounds().size.x / 2.f, enterText.getLocalBounds().size.y / 2.f });
    enterText.setPosition({ optionText.getPosition().x, optionText.getPosition().y + 100.f });

    sf::Texture texture;

    sf::RectangleShape swordSquare, shieldSquare, gearSquare;
    setupSquares(swordSquare, shieldSquare, gearSquare, outlineSquare);

    ensureGearFileExistsAndValid();
    int swordValue = 0, shieldValue = 0, gearValue = 0;
    loadGearValues(swordValue, shieldValue, gearValue);

    sf::Texture gearTexture("assets/gear/Gear.png");
    sf::Texture armorTexture("assets/gear/armor.png");
    sf::Sprite swordSprite(gearTexture);
    sf::Sprite shieldSprite(gearTexture);
    sf::Sprite gearSprite(armorTexture);
    if (swordValue < 0) {
        swordValue = 0;
    }
    else if (swordValue > 13) {
        swordValue = 13;
    }
    if (shieldValue < 0) {
        shieldValue = 0;
    }
    else if (shieldValue > 13) {
        shieldValue = 13;
    }
    if (gearValue < 0) {
        gearValue = 0;
    }
    else if (gearValue > 10) {
        gearValue = 10;
    }
    if (swordValue <= 13) {
        swordSprite.setTextureRect({ {0, 32 * swordValue}, {32, 32} });
    }
    if (shieldValue <= 13) {
        shieldSprite.setTextureRect({ {128, 32 * shieldValue}, {32, 32} });
    }
    if (gearValue <= 10) {
        if (gearValue <= 4) {
            gearSprite.setTextureRect({ {10 + 42 * gearValue, 4}, {45, 51} });
        }
        else {
            gearSprite.setTextureRect({ {10 + 42 * (gearValue - 5), 55}, {45, 51} });
        }
    }

    // Scale sprites
    swordSprite.setScale({ 2.f, 2.f });
    shieldSprite.setScale({ 2.f, 2.f });
    gearSprite.setScale({ 2.f, 2.f });

    // Set origin using bounds.size.x and bounds.size.y, consistent with staticSprite logic
    sf::FloatRect swordBounds = swordSprite.getLocalBounds();
    swordSprite.setOrigin({ swordBounds.size.x / 2.f, swordBounds.size.y / 2.f });

    sf::FloatRect shieldBounds = shieldSprite.getLocalBounds();
    shieldSprite.setOrigin({ shieldBounds.size.x / 2.f, shieldBounds.size.y / 2.f });

    sf::FloatRect gearBounds = gearSprite.getLocalBounds();
    gearSprite.setOrigin({ gearBounds.size.x / 2.f, gearBounds.size.y / 2.f });

    // Position the sprites in the center of their corresponding squares
    swordSprite.setPosition({
        swordSquare.getPosition().x + swordSquare.getSize().x / 2.f,
        swordSquare.getPosition().y + swordSquare.getSize().y / 2.f
        });
    shieldSprite.setPosition({
        shieldSquare.getPosition().x + shieldSquare.getSize().x / 2.f,
        shieldSquare.getPosition().y + shieldSquare.getSize().y / 2.f
        });
    gearSprite.setPosition({
        gearSquare.getPosition().x + gearSquare.getSize().x / 2.f,
        gearSquare.getPosition().y + gearSquare.getSize().y / 2.f
        });

    float rightX = static_cast<float>(window.getSize().x) * 0.85f;
    float bottomY = static_cast<float>(window.getSize().y) / 2.f - 100.f;
    float hp = 100 + static_cast<float>(pow(10, gearValue));
    float defence = 1 + static_cast<float>(pow(10, shieldValue));
    float attack = 20 + static_cast<float>(pow(10, swordValue));
    sf::Text statsTitle(font);
    statsTitle.setString("Stats");
    statsTitle.setCharacterSize(36);
    statsTitle.setFillColor(sf::Color::White);
    statsTitle.setOrigin({ statsTitle.getLocalBounds().size.x / 2.f, statsTitle.getLocalBounds().size.y / 2.f });
    statsTitle.setPosition({ rightX, bottomY });

    sf::Text attackText(font);
    std::ostringstream attackStream;
    attackStream << std::fixed << std::setprecision(1) << attack;
    attackText.setString("Attack: " + attackStream.str());
    attackText.setCharacterSize(24);
    attackText.setFillColor(sf::Color::White);
    attackText.setOrigin({ 0.f, 0.f });
    attackText.setPosition({ rightX - 50.f, bottomY + 40.f });

    sf::Text hpText(font);

    std::ostringstream hpStream;
    hpStream << std::fixed << std::setprecision(1) << hp;
    hpText.setString("HP: " + hpStream.str());
    hpText.setCharacterSize(24);
    hpText.setFillColor(sf::Color::White);
    hpText.setOrigin({ 0.f, 0.f });
    hpText.setPosition({ rightX - 50.f, bottomY + 70.f });

    sf::Text defenceText(font);
    std::ostringstream defenceStream;
    defenceStream << std::fixed << std::setprecision(1) << defence;
    defenceText.setString("Defence: " + defenceStream.str());
    defenceText.setCharacterSize(24);
    defenceText.setFillColor(sf::Color::White);
    defenceText.setOrigin({ 0.f, 0.f });
    defenceText.setPosition({ rightX - 50.f, bottomY + 100.f });

    sf::Text speedText(font);
    speedText.setString("Speed: 1.0");
    speedText.setCharacterSize(24);
    speedText.setFillColor(sf::Color::White);
    speedText.setOrigin({ 0.f, 0.f });
    speedText.setPosition({ rightX - 50.f, bottomY + 130.f });

    static Mob* boss = new FlyingEye();
    boss->getSprite().setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) - 200.f });
    auto confirmSelection = [&]() {
        if (currentIndex == 0) add = "1/NoOutline/PNG/";
        else if (currentIndex == 1) add = "1/Outline/PNG/";
        else if (currentIndex == 2) add = "2/NoOutline/PNG/";
        else if (currentIndex == 3) add = "2/Outline/PNG/";

        folder += add;
        player.setAttack(attack);
        player.setDef(defence);
        player.setHp(hp);
        player.setFolder(folder);
        };

    while (window.isOpen()) {
        boss->animateMove();
        while (const std::optional<sf::Event> event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>()) window.close();
            if (event->is<sf::Event::MouseMoved>()) {
                sf::Vector2f worldPos = window.mapPixelToCoords(sf::Mouse::getPosition(window));
                settings_sprite.setColor(settings_sprite.getGlobalBounds().contains(worldPos) ? sf::Color(255, 255, 255, 128) : sf::Color(255, 255, 255, 255));
                leftTriangle.setFillColor(leftTriangle.getGlobalBounds().contains(worldPos) ? sf::Color::Yellow : sf::Color::White);
                rightTriangle.setFillColor(rightTriangle.getGlobalBounds().contains(worldPos) ? sf::Color::Yellow : sf::Color::White);
                enterText.setFillColor(enterText.getGlobalBounds().contains(worldPos) ? sf::Color::Yellow : sf::Color::White);
            }

            if (event->is<sf::Event::KeyPressed>()) {
                const auto* key = event->getIf<sf::Event::KeyPressed>();
                if (!key) continue;
                if (exit(key->code, window)) return;

                if (key->code == sf::Keyboard::Key::Right) {
                    currentIndex = (currentIndex + 1) % options.size();
                    updateOption();
                }
                else if (key->code == sf::Keyboard::Key::Left) {
                    currentIndex = (currentIndex - 1 + options.size()) % options.size();
                    updateOption();
                }


                if (key->code == sf::Keyboard::Key::Enter) {
                    confirmSelection();
                    return;
                }
            }

            if (event->is<sf::Event::MouseButtonPressed>()) {
                sf::Vector2f worldPos = window.mapPixelToCoords(sf::Mouse::getPosition(window));

                if (settings_sprite.getGlobalBounds().contains(worldPos)) {
                    Settings(window);
                    settings_sprite.setColor(sf::Color(255, 255, 255, 255));
                    window.setView(window.getDefaultView());
                }

                if (leftTriangle.getGlobalBounds().contains(worldPos)) {
                    currentIndex = (currentIndex - 1 + options.size()) % options.size();
                    updateOption();
                    boss->resetAnimation();
                    boss->animateAttack();
                }
                if (rightTriangle.getGlobalBounds().contains(worldPos)) {
                    currentIndex = (currentIndex + 1) % options.size();
                    updateOption();
                    boss->resetAnimation();
                    boss->animateAttack();
                }

                if (enterText.getGlobalBounds().contains(worldPos)) {
                    confirmSelection();
                    return;
                }
            }
        }

        window.clear(sf::Color::Black);
        window.draw(backgroundSprite);
        window.draw(staticSprite);
        window.draw(outlineSquare);
        window.draw(swordSquare);
        window.draw(shieldSquare);
        window.draw(gearSquare);
        window.draw(swordSprite);
        window.draw(gearSprite);
        window.draw(shieldSprite);
        window.draw(settings_sprite);
        window.draw(leftTriangle);
        window.draw(rightTriangle);
        window.draw(optionText);
        window.draw(enterText);
        window.draw(statsTitle);
        window.draw(attackText);
        window.draw(hpText);
        window.draw(defenceText);
        window.draw(speedText);
        window.draw(boss->getSprite());
        window.display();
    }
}
