#include "Classes.h"
#include "Settings.h"

// Handles back or exit key events. Returns true if the function should return.
bool exit(sf::Keyboard::Key code, sf::RenderWindow& window) {
    if (code == sf::Keyboard::Key::Backspace) {
        return true;  // Signal to go back
    }
    if (code == sf::Keyboard::Key::Escape) {
        //Smooth exit
        for (float v = backgroundMusic.getVolume(); v >= 0.f; v -= 5.f) {
            backgroundMusic.setVolume(v);
            sleep(sf::milliseconds(20));
        }
        backgroundMusic.stop();
        window.close();  // Quit the application
    }
    return false;
}
// Navigates up/down in a menu list and updates highlight colors
void navigateMenu(std::vector<sf::Text>& options, std::size_t& selectedIndex, sf::Keyboard::Key code, std::size_t n) {
    if (code == sf::Keyboard::Key::Up && selectedIndex > n) {
        options[selectedIndex].setFillColor(sf::Color::White);
        --selectedIndex;
        options[selectedIndex].setFillColor(sf::Color::Yellow);
    }
    else if (code == sf::Keyboard::Key::Down && selectedIndex < options.size() - 1) {
        options[selectedIndex].setFillColor(sf::Color::White);
        ++selectedIndex;
        options[selectedIndex].setFillColor(sf::Color::Yellow);
    }
}

// Draws a menu with a title and a list of options
void renderMenu(sf::RenderWindow& window, const sf::Text& title, const std::vector<sf::Text>& options) {
    sf::Sprite backgroundSprite(backgroundTexture);

    window.clear();
    window.draw(backgroundSprite);
    window.draw(title);
    for (const auto& text : options)
        window.draw(text);

    window.display();
}

int getVolumeTier(float volume) {
    if (volume <= 33.f) return 0;
    if (volume <= 66.f) return 1;
    return 2;
}

void placeText(sf::Text& text, const sf::RenderWindow& window, float& y, unsigned spacing) {
    text.setPosition({ 0, y });
    y += static_cast<float>(spacing);
}

// Computes volume based on mouse position within a slider bar
float computeVolumeFromMouse(float mouseX, const sf::Sprite& bar) {
    float actualWidth = bar.getScale().x * static_cast<float>(bar.getTextureRect().size.x);
    float barLeft = bar.getPosition().x - actualWidth / 2.f;

    float clampedX = std::max(barLeft + 50.f, std::min(mouseX, barLeft + actualWidth - 50.f));
    float volume = ((clampedX - barLeft - 50.f) / (actualWidth - 2 * 50.f)) * 100.f;
    return volume;
}

// Moves the slider rectangle to match a volume level
void setSliderPositionFromVolume(sf::Sprite& slider, float volume, const sf::Sprite& bar) {
    float actualWidth = bar.getScale().x * static_cast<float>(bar.getTextureRect().size.x);
    float actualHeight = bar.getScale().y * static_cast<float>(bar.getTextureRect().size.y);

    // Adjust bar position since origin is centered
    float barLeft = bar.getPosition().x - actualWidth / 2.f;
    float barTop = bar.getPosition().y - actualHeight / 2.f;

    float x = barLeft + 50.f + (volume / 100.f * (actualWidth - 2 * 50.f));
    float y = barTop + (actualHeight - slider.getGlobalBounds().size.y) / 2.f;

    slider.setPosition({ x, y + slider.getGlobalBounds().size.y / 2.f });
}

void Sound(sf::RenderWindow& window) {
    float y = 100.f;

    window.setTitle("Audio");
    sf::Texture base;
    if (!base.loadFromFile("assets/UI/Sound.png")) {
        std::cerr << "Failed to load sound texture" << std::endl;
    }
    sf::Text volumeText(font, "Volume", 30);
    volumeText.setPosition({ 50.f, y });

    sf::Sprite sliderBar(base);
    sliderBar.setTextureRect({ {0, 30}, {49, 20} });
    sliderBar.setScale({ 7.f, 7.f });
    sf::FloatRect bounds = sliderBar.getLocalBounds();
    sliderBar.setOrigin({ bounds.size.x / 2.f, bounds.size.y / 2.f });
    sliderBar.setPosition({ 180.f, y + 100.f });

    sf::Sprite slider(base);
    slider.setTextureRect({ {176, 100}, {16, 24} });
    slider.setScale({ 4.f, 4.f });
    sf::FloatRect sliderBounds = slider.getLocalBounds();
    //Set the origin of the slider to the middle
    slider.setOrigin({ sliderBounds.size.x / 2.f, sliderBounds.size.y / 2.f });
    //Move slider's position according to the volume level
    setSliderPositionFromVolume(slider, backgroundMusic.getVolume(), sliderBar);

    sf::Text percentText(font, "", 20);
    percentText.setPosition({ 50.f, y + 85 });
    percentText.setFillColor(sf::Color::White);

    bool dragging = false;

    while (window.isOpen()) {
        while (const std::optional<sf::Event> event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>())
                window.close();

            if (event->is<sf::Event::KeyPressed>()) {
                const auto* key = event->getIf<sf::Event::KeyPressed>();
                if (!key) continue;
                if (exit(key->code, window))
                    return;
            }

            if (event->is<sf::Event::MouseButtonPressed>()) {
                sf::Vector2i pixelPos = sf::Mouse::getPosition(window);
                sf::Vector2f worldPos = window.mapPixelToCoords(pixelPos);
                if (slider.getGlobalBounds().contains(worldPos))
                    dragging = true;
            }

            if (event->is<sf::Event::MouseButtonReleased>()) {
                dragging = false;
            }

            if (event->is<sf::Event::MouseMoved>() && dragging) {
                float mouseX = window.mapPixelToCoords(sf::Mouse::getPosition(window)).x;
                float volume = computeVolumeFromMouse(mouseX, sliderBar);
                backgroundMusic.setVolume(volume);
                setSliderPositionFromVolume(slider, volume, sliderBar);
                percentText.setString(std::to_string(static_cast<int>(volume)) + "%");
                if (volume < 33.f) {
                    sliderBar.setTextureRect({ {0, 30}, {49, 20} });
                }
                else if (volume < 67.f) {
                    sliderBar.setTextureRect({ {64, 30}, {49, 20} });
                }
                else {
                    sliderBar.setTextureRect({ {128, 30}, {49, 20} });
                }
            }
        }
        // Draw everything
        window.clear();
        window.draw(volumeText);
        window.draw(sliderBar);
        window.draw(slider);
        window.draw(percentText);
        window.display();
    }
}

// Enum for resolution options
enum ResolutionOption {
    RES_800x600,
    RES_1024x768,
    RES_1280x720,
    RES_1920x1080,
    RES_2560x1440,
    RES_2560x1600,
    RES_SYSTEM_RESOLUTION
};

// Map resolutions to their sizes
const std::pmr::map<ResolutionOption, sf::Vector2u> resolutionSizes = {
    {RES_800x600, {800, 600}},
    {RES_1024x768, {1024, 768}},
    {RES_1280x720, {1280, 720}},
    {RES_1920x1080, {1920, 1080}},
    {RES_2560x1440, {2560, 1440}},
    {RES_2560x1600, {2560, 1600}},
    {RES_SYSTEM_RESOLUTION, sf::VideoMode::getDesktopMode().size}
};

void updateTextPositions(sf::Text& title, std::vector<sf::Text>& options, const sf::RenderWindow& window, float& y, unsigned size_y) {
    y = 0;
    placeText(title, window, y, size_y / 8);
    for (auto& text : options)
        placeText(text, window, y, size_y / 8);
}

void changeResolution(sf::RenderWindow& window, ResolutionOption option) {
    auto it = resolutionSizes.find(option);
    if (it != resolutionSizes.end()) {
        window.setSize(it->second);
        window.setView(window.getDefaultView());
    }
    else {
        std::cerr << "Unknown resolution option\n";
    }
}

void updateSelectionHighlight(std::vector<sf::Text>& options, std::size_t oldIndex, std::size_t newIndex) {
    if (oldIndex < options.size())
        options[oldIndex].setFillColor(sf::Color::White);
    if (newIndex < options.size())
        options[newIndex].setFillColor(sf::Color::Yellow);
}

void handleMouseMove(const sf::Event::MouseMoved& mouseMove, std::vector<sf::Text>& options, std::size_t& selectedIndex, const sf::RenderWindow& window) {
    sf::Vector2f worldPos = window.mapPixelToCoords({ mouseMove.position.x, mouseMove.position.y });

    for (std::size_t i = 0; i < options.size(); ++i) {
        if (options[i].getGlobalBounds().contains(worldPos)) {
            if (selectedIndex != i) {
                updateSelectionHighlight(options, selectedIndex, i);
                selectedIndex = i;
            }
            break;
        }
    }
}

void handleMouseClick(sf::RenderWindow& window, std::vector<sf::Text>& options, const sf::Event::MouseButtonPressed& mouseButton, std::size_t& selectedIndex, sf::Text& title, float& y, unsigned size_y) {
    sf::Vector2f worldPos = window.mapPixelToCoords({ mouseButton.position.x, mouseButton.position.y });

    for (std::size_t i = 0; i < options.size(); ++i) {
        if (options[i].getGlobalBounds().contains(worldPos)) {
            changeResolution(window, static_cast<ResolutionOption>(i));
            updateTextPositions(title, options, window, y, size_y);
            updateSelectionHighlight(options, selectedIndex, i);
            selectedIndex = i;
            break;
        }
    }
}
void handleKeyPress(const sf::Event::KeyPressed& key, sf::RenderWindow& window, std::vector<sf::Text>& options, std::size_t& selectedIndex, sf::Text& title, float& y, unsigned size_y) {
    if (exit(key.code, window)) return;

    navigateMenu(options, selectedIndex, key.code, 0);

    if (key.code == sf::Keyboard::Key::Enter) {
        changeResolution(window, static_cast<ResolutionOption>(selectedIndex));
        updateTextPositions(title, options, window, y, size_y);
    }
}

void Resolution(sf::RenderWindow& window) {
    unsigned size_y = sf::VideoMode::getDesktopMode().size.y;
    float y = 0.f;
    sf::Text title(font, "Resolutions:", 50);

    std::vector<sf::Text> options = {
        sf::Text(font, "800x600", 25),
        sf::Text(font, "1024x768", 25),
        sf::Text(font, "1280x720", 25),
        sf::Text(font, "1920x1080", 25),
        sf::Text(font, "2560x1440", 25),
        sf::Text(font, "2560x1600", 25),
        sf::Text(font, "SYSTEM RESOLUTION", 30),
    };

    updateTextPositions(title, options, window, y, size_y);

    std::size_t selectedIndex = RES_800x600;
    options[selectedIndex].setFillColor(sf::Color::Yellow);

    while (window.isOpen()) {
        while (const std::optional<sf::Event> event = window.pollEvent()) {
            if (!event.has_value()) continue;

            if (event->is<sf::Event::Closed>()) {
                window.close();
            }
            else if (event->is<sf::Event::MouseMoved>()) {
                const auto& mouseMove = *event->getIf<sf::Event::MouseMoved>();
                handleMouseMove(mouseMove, options, selectedIndex, window);
            }
            else if (event->is<sf::Event::MouseButtonPressed>()) {
                if (event->getIf<sf::Event::MouseButtonPressed>()->button == sf::Mouse::Button::Left) {
                    handleMouseClick(window, options, *event->getIf<sf::Event::MouseButtonPressed>(), selectedIndex, title, y, size_y);
                }
            }
            else if (event->is<sf::Event::KeyPressed>()) {
                const auto& keyEvent = *event->getIf<sf::Event::KeyPressed>();
                if (exit(keyEvent.code, window)) {
                    return;
                }
                handleKeyPress(keyEvent, window, options, selectedIndex, title, y, size_y);
            }
        }
        renderMenu(window, title, options);
    }
}

void Settings(sf::RenderWindow& window) {
    window.setTitle("Settings");
    float y{};
    unsigned size_y{ sf::VideoMode::getDesktopMode().size.y };
    sf::Text title(font, "Settings", 75);
    std::vector options = {
        sf::Text(font, "Resolution", 50),
        sf::Text(font, "Sound", 50),
        sf::Text(font, "Enter", 50)
    };

    std::size_t selectedIndex = 0;
    options[selectedIndex].setFillColor(sf::Color::Yellow);

    placeText(title, window, y, size_y / 9);
    for (auto& text : options)
        placeText(text, window, y, size_y / 9);

    while (window.isOpen()) {
        while (const std::optional<sf::Event> event = window.pollEvent()) {
            if (event->is<sf::Event::Closed>())
                window.close();
            if (event->is<sf::Event::MouseMoved>()) {
                sf::Vector2f worldPos = window.mapPixelToCoords({
                    event->getIf<sf::Event::MouseMoved>()->position.x,
                    event->getIf<sf::Event::MouseMoved>()->position.y
                    });
                for (std::size_t i = 0; i < options.size(); ++i) {
                    if (options[i].getGlobalBounds().contains(worldPos)) {
                        if (selectedIndex != i) {
                            if (selectedIndex < options.size())
                                options[selectedIndex].setFillColor(sf::Color::White);
                            options[i].setFillColor(sf::Color::Yellow);
                            selectedIndex = i;
                        }
                        break;
                    }
                }
            }
            if (event->is<sf::Event::MouseButtonPressed>() && event->getIf<sf::Event::MouseButtonPressed>()->button == sf::Mouse::Button::Left) {
                sf::Vector2i pixelPos = sf::Mouse::getPosition(window);
                sf::Vector2f worldPos = window.mapPixelToCoords(pixelPos);
                for (std::size_t i = 0; i < options.size(); ++i) {
                    if (options[i].getGlobalBounds().contains(worldPos)) {
                        switch (i) {
                        case 0: Resolution(window); break;
                        case 1: Sound(window); break;
                        case 2: return;
                        default: break;
                        }
                    }
                }
            }
            if (event->is<sf::Event::KeyPressed>()) {
                const auto* key = event->getIf<sf::Event::KeyPressed>();
                if (!key) continue;
                if (exit(key->code, window))
                    return;
                if (key->code == sf::Keyboard::Key::Up && selectedIndex > 0) {
                    options[selectedIndex].setFillColor(sf::Color::White);
                    --selectedIndex;
                    options[selectedIndex].setFillColor(sf::Color::Yellow);
                }
                else if (key->code == sf::Keyboard::Key::Down && selectedIndex < options.size() - 1) {
                    options[selectedIndex].setFillColor(sf::Color::White);
                    ++selectedIndex;
                    options[selectedIndex].setFillColor(sf::Color::Yellow);
                }
                else if (key->code == sf::Keyboard::Key::Enter) {
                    switch (selectedIndex) {
                    case 0: Resolution(window); break;
                    case 1: Sound(window); break;
                    case 2: return;
                    default: break;
                    }
                }
            }
        }
        renderMenu(window, title, options);
    }
}
