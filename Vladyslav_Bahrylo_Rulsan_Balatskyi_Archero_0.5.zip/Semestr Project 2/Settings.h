
#include "Classes.h"

// Function declarations
void Settings(sf::RenderWindow& window);
void Resolution(sf::RenderWindow& window);
void Sound(sf::RenderWindow& window);
bool exit(sf::Keyboard::Key code, sf::RenderWindow& window);




