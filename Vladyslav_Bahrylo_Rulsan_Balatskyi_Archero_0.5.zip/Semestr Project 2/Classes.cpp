﻿#include "Classes.h"
#include "Menu.h"
#include "Waves.h"

//Knight model 120x80
sf::Texture createTexture(int x, int y) {
    unsigned int width = x;
    unsigned int height = y;
    unsigned int blockSize = 10;
    sf::RenderTexture renderTexture({ width, height });

    renderTexture.clear(sf::Color::White);

    for (unsigned int y = 0; y < height; y += blockSize) {
        for (unsigned int x = 0; x < width; x += blockSize) {
            if (((x / blockSize) + (y / blockSize)) % 2 == 0) {
                sf::RectangleShape square({ static_cast<float>(blockSize), static_cast<float>(blockSize) });
                square.setPosition({ static_cast<float>(x), static_cast<float>(y) });
                square.setFillColor(sf::Color::Black);
                renderTexture.draw(square);
            }
        }
    }
    sf::Texture texture = renderTexture.getTexture();
    return texture;
}

Game::Game() : window(sf::VideoMode::getDesktopMode(), "Archero 0.5") {
}

//Window getter
sf::RenderWindow& Game::getWindow() {
    return window;
}

Character::Character() : attack(0), defense(0), hp(100), speed(1.0), level(1), folder("assets/Knight/"), texture(sf::Texture()), sprite(texture) {
    sprite.setOrigin({ 60.f, 40.f });
}

void Character::setAttack(float a) { attack = a; }
void Character::setDef(float d) { defense = d; }
void Character::setHp(float h) { hp = h; }
void Character::setSpeed(float s) { speed = s; }
void Character::setLevel(unsigned l) { level = l; }
void Character::setFolder(std::string f) { folder = std::move(f); }
void Character::setSprite(sf::Sprite& newSprite) { sprite = newSprite; }

float Character::getAttack() const { return attack; }
float Character::getHp() const { return hp; }
float Character::getDef() const { return defense; }
float Character::getSpeed() const { return speed; }
unsigned Character::getLevel() const { return level; }
std::string Character::getFolder() { return folder; }
sf::Sprite& Character::getSprite() { return sprite; }

void Character::animate(int frames) {
    const int frameWidth = 120;
    const int frameHeight = 80;
    sf::Time frameDuration = sf::milliseconds(100);

    if (animationFinished) return;

    if (frameClock.getElapsedTime() >= frameDuration) {
        sprite.setTextureRect({ {currentFrame * frameWidth, 0}, {frameWidth, frameHeight} });
        currentFrame++;
        if (currentFrame >= frames) {
            currentFrame = frames - 1;
            animationFinished = true;
        }
        frameClock.restart();
    }
}

void Character::resetAnimation() {
    if (resetDelayClock.getElapsedTime().asSeconds() >= resetDelay) {
        currentFrame = 0;
        animationFinished = false;
        frameClock.restart();
        resetDelayClock.restart();
    }
}

bool Character::isAnimationFinished() const {
    return animationFinished;
}

void Character::handleEvent(const sf::Event& event) {
    if (const auto* keyEvent = event.getIf<sf::Event::KeyPressed>()) {
        const sf::Keyboard::Key key = keyEvent->code;
        if (key == sf::Keyboard::Key::W) movingUp = true;
        if (key == sf::Keyboard::Key::S) movingDown = true;
        if (key == sf::Keyboard::Key::A) {
            movingLeft = true;
            sprite.setOrigin({ sprite.getLocalBounds().size.x / 2.f, sprite.getLocalBounds().size.y / 2.f });
            sprite.setScale({ -2.f, 2.f });
        }
        if (key == sf::Keyboard::Key::D) {
            movingRight = true;
            sprite.setOrigin({ sprite.getLocalBounds().size.x / 2.f, sprite.getLocalBounds().size.y / 2.f });
            sprite.setScale({ 2.f, 2.f });
        }
    }

    if (const auto* keyEvent = event.getIf<sf::Event::KeyReleased>()) {
        const sf::Keyboard::Key key = keyEvent->code;
        if (key == sf::Keyboard::Key::W) movingUp = false;
        if (key == sf::Keyboard::Key::S) movingDown = false;
        if (key == sf::Keyboard::Key::A) movingLeft = false;
        if (key == sf::Keyboard::Key::D) movingRight = false;
    }
    int count = 0;
    if (movingUp) count++;
    if (movingDown) count++;
    if (movingLeft) count++;
    if (movingRight) count++;

    if (count > 2) {
        movingUp = false;
        movingDown = false;
        movingLeft = false;
        movingRight = false;
    }
}

void Character::move(sf::Window& window) {
    float deltaTime = moveClock.restart().asSeconds();
    float moveSpeed = 250.f * speed;

    sf::Vector2f movement(0.f, 0.f);
    sf::Vector2f pos = sprite.getPosition();
    sf::Vector2u winSize = window.getSize();

    if (movingUp)    movement.y -= 1.f;
    if (movingDown)  movement.y += 1.f;
    if (movingLeft)  movement.x -= 1.f;
    if (movingRight) movement.x += 1.f;

    float length = std::sqrt(movement.x * movement.x + movement.y * movement.y);
    if (length != 0.f) {
        movement /= length;

        sf::Vector2f scaledMove = movement * moveSpeed * deltaTime;
        sf::Vector2f newPos = pos + scaledMove;
        if (movement.x < 0) {
            sprite.setScale({ -2.f, 2.f });
            sprite.setOrigin({ sprite.getLocalBounds().size.x / 2.f, sprite.getLocalBounds().size.y / 2.f });
        }
        else if (movement.x > 0) {
            sprite.setScale({ 2.f, 2.f });
            sprite.setOrigin({ sprite.getLocalBounds().size.x / 2.f, sprite.getLocalBounds().size.y / 2.f });
        }
        // Check window boundaries before moving
        if (newPos.x > 0 && newPos.x < static_cast<float>(winSize.x) && newPos.y > 0 && newPos.y < static_cast<float>(winSize.y)) { sprite.move(scaledMove); }
        animateMove();
    }
    else { animateIdle(); }
}

sf::Texture Character::loadTexture(const std::string& fileName) {
    sf::Texture tex;
    std::string filePath = folder + fileName;
    if (!tex.loadFromFile(filePath)) {
        std::cerr << "Failed to load: " << filePath << '\n';
        tex = createTexture(120, 80);
    }
    return tex;
}
void Character::animateAttack() {
    int frames = 4;
    texture = loadTexture("_Attack.png");
    sprite.setTexture(texture);
    animate(frames);
}
void Character::animateDeath() {
    int frames = 10;
    texture = loadTexture("_Death.png");
    sprite.setTexture(texture);
    animate(frames);
}

void Character::animateIdle() {
    texture = loadTexture("_Idle.png");
    sprite.setTexture(texture);
    int frames = texture.getSize() == sf::Vector2u(120, 80) ? 4 : 0;
    animate(frames);
}
void Character::animateMove() {
    texture = loadTexture("_Run.png");
    sprite.setTexture(texture);
    int frames = 10;
    animate(frames);
}

// Loading essential game assets
void loadAssets() {
    if (!font.openFromFile("assets/Font.ttf")) {
        throw std::runtime_error("Failed to load font");
    }

    if (!backgroundMusic.openFromFile("assets/Music.mp3")) {
        throw std::runtime_error("Failed to load background music");
    }

    if (!backgroundTexture.loadFromFile("assets/background.jpg")) {
        throw std::runtime_error("Failed to load background texture");
    }
}

void Game::run() {
    try {
        loadAssets();
    }
    catch (const std::exception& e) {
        const std::string error = e.what();

        if (error.find("font") != std::string::npos) {
            std::cerr << "Font load failed. Using SFML default font fallback.\n";
            font = sf::Font();
        }
        if (error.find("music") != std::string::npos) {
            std::cerr << "Music load failed. Muting music.\n";
            backgroundMusic.stop();
        }
        if (error.find("background texture") != std::string::npos) {
            std::cerr << "Background texture load failed. Using generated fallback.\n";
            backgroundTexture = createTexture(static_cast<int>(window.getSize().x), static_cast<int>(window.getSize().y));
        }
    }
    backgroundMusic.play();
    while (window.isOpen()) {
        mainMenu(window, player);

        // Reset player stats before each new game
        player.setLevel(1);

        waves(window, &player);
    }
}

