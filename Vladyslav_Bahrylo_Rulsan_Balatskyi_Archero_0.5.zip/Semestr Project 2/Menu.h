#ifndef MENU_H
#define MENU_H

#pragma once
#include "Classes.h"

void mainMenu(sf::RenderWindow& window, Character& player);
void ensureGearFileExistsAndValid();

#endif //MENU_H
