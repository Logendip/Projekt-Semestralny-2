﻿#include "Waves.h"

// Spawn next wave with delay if all mobs are dead
sf::Clock waveDelayClock;
bool waitingForNextWave = false;
float waveDelaySeconds = 3.0f;
//time pause for text
sf::Clock waveTextClock;

struct Bomb {
    sf::Sprite sprite;
    int currentFrame;
    float elapsedTime;

    explicit Bomb(const sf::Texture& texture) : sprite(texture) {
        currentFrame = 0;
        elapsedTime = 0.f;
    }
};

void incrementGearValue() {
    int sword = 0, shield = 0, gear = 0;
    std::ifstream infile("gear.txt");
    if (infile.is_open()) {
        infile >> sword >> shield >> gear;
        infile.close();
    }

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dist(1, 3);
    switch (dist(gen)) {
    case(1): sword++; break;
    case(2): shield++; break;
    case(3): gear++; break;
    default: break;
    }

    std::ofstream outfile("gear.txt");
    if (outfile.is_open()) {
        outfile << sword << "\n" << shield << "\n" << gear << "\n";
        outfile.close();
    }
}

void touchBomb(std::vector<Bomb>& bombs, const sf::Texture& texture, sf::Vector2f position) {
    Bomb newBomb(texture);

    int frameWidth = static_cast<int>(texture.getSize().x / 14);
    int frameHeight = static_cast<int>(texture.getSize().y);

    newBomb.sprite.setOrigin({ static_cast<float>(frameWidth) / 2.f, static_cast<float>(frameHeight) / 2.f });
    newBomb.sprite.setTextureRect({ {0, 0}, {frameWidth, frameHeight} });
    newBomb.sprite.setPosition(position);
    newBomb.sprite.setScale({ 2.f, 2.f });

    bombs.push_back(newBomb);
}

void drawBombs(sf::RenderWindow& window, std::vector<Bomb>& bombs, const sf::Texture& texture, float bombClock) {
    const int totalFrames = 14;
    const float frameDuration = 0.05f;  // 50ms per frame
    const int frameWidth = static_cast<int>(texture.getSize().x / totalFrames);
    const int frameHeight = static_cast<int>(texture.getSize().y);

    for (size_t i = 0; i < bombs.size();) {
        Bomb& bomb = bombs[i];
        bomb.elapsedTime += bombClock;

        if (bomb.elapsedTime >= frameDuration) {
            bomb.elapsedTime = 0.f;
            bomb.currentFrame++;

            if (bomb.currentFrame < totalFrames) {
                bomb.sprite.setTextureRect({
                    {(bomb.currentFrame * frameWidth), 0},
                    {frameWidth, frameHeight}
                    });
            }
            else {
                bombs.erase(bombs.begin() + static_cast<std::vector<Bomb>::difference_type>(i));
                continue;
            }
        }

        window.draw(bomb.sprite);
        ++i;
    }
}


sf::Sprite generateMapTexture(const sf::RenderWindow& window, bool& animationDone) {
    const int tileCountX = 20;
    const int tileCountY = 12;

    static sf::Texture* grassTexture1 = nullptr;
    static sf::Texture* grassTexture2 = nullptr;
    static sf::Texture* rockTexture = nullptr;

    static bool texturesLoaded = false;
    if (!texturesLoaded) {
        grassTexture1 = new sf::Texture();
        grassTexture2 = new sf::Texture();
        rockTexture = new sf::Texture();

        if (!grassTexture1->loadFromFile("assets/Grass_1.png") ||
            !grassTexture2->loadFromFile("assets/Grass_2.png") ||
            !rockTexture->loadFromFile("assets/stone_1.png")) {
            std::cerr << "Error loading textures!" << std::endl;
            animationDone = true;
            return sf::Sprite(*grassTexture1);
        }
        texturesLoaded = true;
    }

    sf::Vector2u winSize = window.getSize();
    float tileWidth = static_cast<float>(winSize.x) / static_cast<float>(tileCountX);
    float tileHeight = static_cast<float>(winSize.y) / static_cast<float>(tileCountY);

    static sf::Sprite* tileSprite1 = nullptr;
    static sf::Sprite* tileSprite2 = nullptr;
    static sf::Sprite* rockSprite = nullptr;

    if (!tileSprite1) {
        tileSprite1 = new sf::Sprite(*grassTexture1);
        tileSprite1->setScale({
            tileWidth / static_cast<float>(grassTexture1->getSize().x),
            tileHeight / static_cast<float>(grassTexture1->getSize().y)
            });
    }
    if (!tileSprite2) {
        tileSprite2 = new sf::Sprite(*grassTexture2);
        tileSprite2->setScale({
            tileWidth / static_cast<float>(grassTexture2->getSize().x),
            tileHeight / static_cast<float>(grassTexture2->getSize().y)
            });
    }
    if (!rockSprite) {
        rockSprite = new sf::Sprite(*rockTexture);
        rockSprite->setScale({
            tileWidth / static_cast<float>(rockTexture->getSize().x),
            tileHeight / static_cast<float>(rockTexture->getSize().y)
            });
    }

    static std::vector<std::vector<int>> tileMap(tileCountY, std::vector<int>(tileCountX));
    static bool tileMapInitialized = false;
    if (!tileMapInitialized) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, 1);

        for (int y = 0; y < tileCountY; ++y) {
            for (int x = 0; x < tileCountX; ++x) {
                tileMap[y][x] = dis(gen);
            }
        }
        tileMapInitialized = true;
    }

    static std::vector<sf::Vector2f> rocks;
    static bool rocksInitialized = false;
    if (!rocksInitialized) {
        const int rockCount = 20;
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_real_distribution<float> randX(0.0f, static_cast<float>(tileCountX) * tileWidth);
        std::uniform_real_distribution<float> randY(0.0f, static_cast<float>(tileCountY) * tileHeight);
        const float minDistanceX = 4.0f * tileWidth;
        const float minDistanceY = 4.0f * tileHeight;

        int attempts = 0;
        while (rocks.size() < static_cast<std::size_t>(rockCount) && attempts < 10000) {
            float rockX = randX(gen);
            float rockY = randY(gen);
            bool valid = true;
            for (const auto& other : rocks) {
                float dx = std::abs(rockX - other.x);
                float dy = std::abs(rockY - other.y);
                if ((dx < minDistanceX && dy < minDistanceY) || std::lround(rockX) == std::lround(other.x) || std::lround(rockY) == std::lround(other.y)) {
                    valid = false;
                    break;
                }
            }
            if (valid) rocks.emplace_back(rockX, rockY);
            attempts++;
        }
        rocksInitialized = true;
    }

    static std::vector<sf::Vector2i> drawOrder;
    static bool drawOrderInitialized = false;
    if (!drawOrderInitialized) {
        int top = 0, bottom = tileCountY - 1, left = 0, right = tileCountX - 1;
        while (top <= bottom && left <= right) {
            for (int x = left; x <= right; ++x) drawOrder.emplace_back(x, top);
            ++top;
            for (int y = top; y <= bottom; ++y) drawOrder.emplace_back(right, y);
            --right;
            if (top <= bottom) {
                for (int x = right; x >= left; --x) drawOrder.emplace_back(x, bottom);
                --bottom;
            }
            if (left <= right) {
                for (int y = bottom; y >= top; --y) drawOrder.emplace_back(left, y);
                ++left;
            }
        }
        drawOrderInitialized = true;
    }

    static sf::RenderTexture* renderTexture = nullptr;
    if (!renderTexture) {
        renderTexture = new sf::RenderTexture();
        renderTexture = new sf::RenderTexture(sf::Vector2u(winSize.x, winSize.y));
        renderTexture->clear();
    }

    static size_t currentTileIndex = 0;
    static sf::Clock spiralClock;
    static bool spiralStarted = false;
    const float spiralDuration = 1.0f;

    if (!spiralStarted) {
        spiralClock.restart();
        spiralStarted = true;
    }

    size_t totalTiles = drawOrder.size();
    float elapsed = spiralClock.getElapsedTime().asSeconds();
    if (elapsed > spiralDuration) elapsed = spiralDuration;


    auto shouldBeDrawn = static_cast<size_t>(static_cast<float>(totalTiles) * (elapsed / spiralDuration));

    for (; currentTileIndex < shouldBeDrawn && currentTileIndex < totalTiles; ++currentTileIndex) {
        sf::Vector2i pos = drawOrder[currentTileIndex];
        int x = pos.x;
        int y = pos.y;

        sf::Sprite& selectedSprite = (tileMap[y][x] == 0) ? *tileSprite1 : *tileSprite2;
        selectedSprite.setPosition({
            static_cast<float>(x) * tileWidth,
            static_cast<float>(y) * tileHeight
            });
        renderTexture->draw(selectedSprite);
    }

    static bool rocksDrawn = false;
    if (!rocksDrawn && currentTileIndex >= drawOrder.size()) {
        for (const auto& pos : rocks) {
            rockSprite->setPosition(pos);
            renderTexture->draw(*rockSprite);
        }
        rocksDrawn = true;
    }

    if (currentTileIndex >= drawOrder.size() && rocksDrawn) {
        renderTexture->display();
        animationDone = true;
    }
    else {
        animationDone = false;
    }

    static sf::Sprite mapSprite(renderTexture->getTexture());
    return mapSprite;
}

void handleEvents(sf::RenderWindow& window) {
    while (const std::optional<sf::Event> event = window.pollEvent()) {
        if (event->is<sf::Event::Closed>()) {
            window.close();
        }
    }
}

int calculateHpLevel(float currentHP, float maxHP, int totalLevels) {
    if (maxHP <= 0 || totalLevels <= 1) return 0;

    float hpPercent = static_cast<float>(currentHP) / static_cast<float>(maxHP);
    int hpLevel = static_cast<int>(std::lround(hpPercent * static_cast<float>(totalLevels - 1)));

    if (hpLevel > 5) hpLevel = 5;
    if (hpLevel < 0) hpLevel = 0;
    hpLevel = 5 - hpLevel;  // Flip hpLevel
    return hpLevel;
}

void updateHpBar(sf::Sprite& hpBarSprite, int hpLevel, int frameWidth, int frameHeight) {
    hpBarSprite.setTextureRect({ {hpLevel * frameWidth + 48, 0}, {frameWidth, frameHeight} });
}

void drawExpBar(sf::RenderWindow& window, sf::RectangleShape& expBarBack, sf::RectangleShape& expBarFront, float expBarWidth, float expRatio) {
    expBarFront.setSize({ expBarWidth * expRatio, 15.f });
    window.draw(expBarBack);
    window.draw(expBarFront);
}

void drawLevelText(sf::RenderWindow& window, sf::Text& levelText, float centerX, float expBarPosY) {
    levelText.setPosition({ centerX, expBarPosY - 30.f });  // Just above the EXP bar
    window.draw(levelText);
}

void drawWaveText(sf::RenderWindow& window, sf::Text& waveText, int waveNumber, sf::Clock& clock, bool& showWaveText, float displayDuration, float fadeDuration) {
    float elapsed = clock.getElapsedTime().asSeconds();

    waveText.setString("Wave " + std::to_string(waveNumber));
    sf::FloatRect textRect = waveText.getLocalBounds();
    waveText.setOrigin({ textRect.size.x / 2.f, textRect.size.y / 2.f });
    waveText.setPosition({ static_cast<float>(window.getSize().x) / 2.f, 200.f });

    if (elapsed < fadeDuration) {
        //Fade in
        float alphaF = (elapsed / fadeDuration) * 255.f;
        unsigned char alpha = static_cast<unsigned char>(std::round(std::clamp(alphaF, 0.f, 255.f)));
        waveText.setFillColor(sf::Color(255, 255, 255, alpha));
    }
    else if (elapsed < displayDuration) {
        //Fade out
        float alphaF = ((displayDuration - elapsed) / fadeDuration) * 255.f;
        unsigned char alpha = static_cast<unsigned char>(std::round(std::clamp(alphaF, 0.f, 255.f)));
        waveText.setFillColor(sf::Color(255, 255, 255, alpha));
    }
    else {
        showWaveText = false;
    }

    window.draw(waveText);
}

void spawnWave(std::vector<std::unique_ptr<Mob>>& mobs, int count, sf::Clock& clock, bool& showWaveText, const sf::RenderWindow& window) {
    mobs.clear();

    std::random_device rd;
    std::mt19937 gen(rd());

    unsigned int windowWidth = window.getSize().x;
    unsigned int windowHeight = window.getSize().y;

    std::uniform_int_distribution<int> distanceX(0, static_cast<int>(windowWidth));
    std::uniform_int_distribution<int> distanceY(0, static_cast<int>(windowHeight));
    std::uniform_int_distribution<int> distanceType(0, 3);

    for (int i = 0; i < count; ++i) {
        int type = distanceType(gen);

        std::unique_ptr<Mob> mob;
        switch (type) {
        case 0: mob = std::make_unique<FlyingEye>(); break;
        case 1: mob = std::make_unique<Goblin>(); break;
        case 2: mob = std::make_unique<Mushroom>(); break;
        case 3: mob = std::make_unique<Skeleton>(); break;
        default: break;
        }

        auto x = static_cast<float>(distanceX(gen));
        auto y = static_cast<float>(distanceY(gen));

        mob->getSprite().setPosition({ x, y });
        mob->resetAnimation();
        mob->animateAttack();
        mobs.push_back(std::move(mob));
    }

    showWaveText = true;
    clock.restart();
}


void updateMobs(std::vector<std::unique_ptr<Mob>>& mobs, int& totalKills, int& kills, int& killsNeededForNextLevel, Character* player, sf::Text& levelText, float& maxHP, float& bombDamage, float& currentHp, std::string& bonusMessage, bool& showBonus, sf::Clock& bonusClock) {
    mobs.erase(
        std::remove_if(mobs.begin(), mobs.end(),
            [&](const std::unique_ptr<Mob>& mob) -> bool {
                if (mob->getHp() <= 0) {
                    mob->animateDeath();
                    if (mob->isAnimationFinished()) {
                        ++kills;
                        // Level up if kills reached threshold
                        if (kills >= killsNeededForNextLevel) {
                            std::random_device rd;
                            std::mt19937 gen(rd());
                            std::uniform_int_distribution<int> bonusDist(1, 2);
                            int bonus = bonusDist(gen);

                            if (bonus == 1) {

                                maxHP *= 1.5f;
                                bonusMessage = "Bonus: Max HP Increased!";
                            }
                            else if (bonus == 2) {

                                bombDamage *= 1.5;
                                bonusMessage = "Bonus: Bomb Damage Increased!";
                            }
                            currentHp = maxHP;

                            showBonus = true;
                            bonusClock.restart();

                            unsigned newLevel = player->getLevel() + 1;
                            player->setLevel(newLevel);
                            levelText.setString("Level " + std::to_string(player->getLevel()));
                            totalKills += kills;
                            kills = 0;
                            killsNeededForNextLevel += 10;
                        }
                        return true;  // remove this mob now
                    }
                    return false;  // keep mob while death animation plays
                }
                return false;  // mob still alive, keep it
            }),
        mobs.end()
    );
}


void waves(sf::RenderWindow& window, Character* player) {
    int totalKills = 0;
    sf::Texture bombTexture;
    if (!bombTexture.loadFromFile("assets/Powers/Bomb.png")) {
        std::cerr << "Failed to load Bomb.png\n";
        bombTexture = createTexture(150.f, 150.f);
    }
    std::vector<Bomb> activeBombs;

    bool mapAnimationDone = false;
    player->getSprite().setPosition({ 500.f, 500.f });
    player->getSprite().setScale({ 2.f, 2.f });
    int kills = 0;
    int killsNeededForNextLevel = 10;  // initial threshold (10 kills)

    sf::Clock mouseClickClock;
    float mouseClickDelay = 1.0f;
    sf::Text mouseTimerText(font);
    mouseTimerText.setCharacterSize(24);
    mouseTimerText.setFillColor(sf::Color::White);
    mouseTimerText.setStyle(sf::Text::Bold);
    mouseTimerText.setPosition({ 20.f, 80.f });

    float bombDamage = 100.f;

    while (!mapAnimationDone && window.isOpen()) {
        sf::Sprite mapSprite = generateMapTexture(window, mapAnimationDone);
        window.clear();
        window.draw(mapSprite);
        window.display();

    }
    // EXP bar width and height
    constexpr float expBarWidth = 300.f;
    constexpr float expBarHeight = 15.f;

    // Center X position for the EXP bar and level text
    const float centerX = static_cast<float>(window.getSize().x) / 2.f;
    const float expBarPosY = 50.f;  // Move it near the top

    // EXP bar background (gray rectangle)
    sf::RectangleShape expBarBack({ expBarWidth, expBarHeight });
    expBarBack.setFillColor(sf::Color(50, 50, 50, 200));  // Grey color
    expBarBack.setOrigin({ expBarWidth / 2.f, expBarHeight / 2.f });  // Set origin to the center
    expBarBack.setPosition({ centerX, expBarPosY });

    // EXP bar foreground (green rectangle that scales with progress)
    sf::RectangleShape expBarFront({ 0.f, expBarHeight });  // initial width 0
    expBarFront.setFillColor(sf::Color(100, 255, 100, 220));  // Green color
    expBarFront.setOrigin({ expBarWidth / 2.f, expBarHeight / 2.f });  // Set origin to the center
    expBarFront.setPosition({ centerX, expBarPosY });

    sf::Text bonusText(font);
    bonusText.setCharacterSize(36);
    bonusText.setFillColor(sf::Color::Yellow);
    bonusText.setStyle(sf::Text::Bold);
    bonusText.setOrigin({ bonusText.getLocalBounds().size.x / 2.f, 0 });
    bonusText.setPosition({ centerX, expBarPosY + 40.f });
    std::string bonusMessage;
    sf::Clock bonusClock;
    bool showBonus = false;

    // Level text
    sf::Text levelText(font);
    levelText.setCharacterSize(24);
    levelText.setFillColor(sf::Color::White);
    levelText.setString("Level " + std::to_string(player->getLevel()));

    // Position level text above the EXP bar, horizontally centered
    const sf::FloatRect textBounds = levelText.getLocalBounds();
    levelText.setOrigin({ textBounds.size.x / 2.f, textBounds.size.y / 2.f });  // Set origin to the center of the text
    levelText.setPosition({ centerX, expBarPosY - 30.f });  // Just above the EXP bar

    int waveNumber = 0;
    float maxHP = player->getHp();
    float currentHp = maxHP;

    // HP bar setup
    sf::Texture hpBarTexture;
    if (!hpBarTexture.loadFromFile("assets/UI/04.png")) {
        std::cerr << "Failed to load hp_bar_sprite.png\n";
        hpBarTexture = createTexture(48.f, 13.f);
    }
    sf::Sprite hpBarSprite(hpBarTexture);
    sf::Sprite backBar(hpBarTexture);
    constexpr int totalLevels = 6;
    constexpr int frameWidth = 48;
    constexpr int frameHeight = 13;

    backBar.setTextureRect({ {0, 0}, {frameWidth, frameHeight} });
    const float hpBarPosX = 20.f;
    const float hpBarPosY = 20.f;
    hpBarSprite.setPosition({ hpBarPosX, hpBarPosY });
    backBar.setPosition({ hpBarPosX, hpBarPosY });
    hpBarSprite.setScale({ 4.f, 4.f });
    backBar.setScale({ 4.f, 4.f });
    hpBarSprite.setOrigin({ 0.f, 0.f });
    backBar.setOrigin({ 0.f, 0.f });

    sf::Text hpText(font);
    try {
        hpText.setCharacterSize(20 - (2 * (std::to_string(static_cast<int>(maxHP)).size())));
    }
    catch (...) {
        hpText.setCharacterSize(13);
    }

    hpText.setOrigin({ hpText.getLocalBounds().size.x / 2.f, hpText.getLocalBounds().size.y });
    hpText.setStyle(sf::Text::Bold);
    hpText.setPosition({ 60.f + backBar.getLocalBounds().size.x / 2.f, 40.f + backBar.getLocalBounds().size.y / 2.f });


    sf::Text waveText(font);
    waveText.setCharacterSize(60);
    waveText.setStyle(sf::Text::Bold);

    sf::Clock clock;
    bool showWaveText = true;

    std::vector<std::unique_ptr<Mob>> mobs;

    // Spawn first wave
    int numberOfMobs = 10;
    spawnWave(mobs, numberOfMobs, clock, showWaveText, window);

    while (window.isOpen()) {
        window.clear();
        hpText.setString(std::to_string(static_cast<long>(currentHp)) + "/" + std::to_string(static_cast<long>(maxHP)));
        //Timer for attack
        float timeLeft = mouseClickDelay - mouseClickClock.getElapsedTime().asSeconds();
        if (timeLeft < 0.f) timeLeft = 0.f;
        mouseTimerText.setString("Bomb timer: " + std::to_string(timeLeft).substr(0, 4) + "s");

        while (const std::optional<sf::Event> event = window.pollEvent()) {
            if (!event.has_value()) break;

            if (event->is<sf::Event::Closed>()) {
                window.close();
                return;
            }

            if (event->is<sf::Event::FocusLost>()) {
                // Stop player movement on window focus lost
                player->movingUp = false;
                player->movingDown = false;
                player->movingLeft = false;
                player->movingRight = false;
            }

            player->handleEvent(*event);

            if (event->is<sf::Event::MouseButtonPressed>() && event->getIf<sf::Event::MouseButtonPressed>()->button == sf::Mouse::Button::Left) {
                if (mouseClickClock.getElapsedTime().asSeconds() >= mouseClickDelay) {
                    sf::Vector2i pixelPos = sf::Mouse::getPosition(window);
                    sf::Vector2f worldPos = window.mapPixelToCoords(pixelPos);

                    // Check if any mob is clicked and instantly kill it
                    for (auto& mob : mobs) {
                        if (mob->getSprite().getGlobalBounds().contains(worldPos)) {
                            if (mob->getHp() <= 100) {
                                mob->setHp(0);
                            }
                            else {
                                mob->setHp(mob->getHp() - bombDamage);
                            }
                        }
                    }

                    // Handle bomb placement or activation
                    touchBomb(activeBombs, bombTexture, worldPos);


                    mouseClickClock.restart();
                }

            }

            /*if (event->is<sf::Event::KeyPressed>()) {
                const auto* key = event->getIf<sf::Event::KeyPressed>();
                if (key && key->code == sf::Keyboard::Key::Num1) {
                    player->animateAttack();
                    isAttacking = true;
                }
            }*/

        }


        // Draw the map
        sf::Sprite mapSprite = generateMapTexture(window, mapAnimationDone);
        window.draw(mapSprite);

        player->move(window);
        player->resetAnimation();

        // End game if HP is 0 or less
        if (currentHp <= 0) {
            //Game over
            sf::Text gameOverText(font);
            gameOverText.setString("Game Over");
            gameOverText.setCharacterSize(60);
            gameOverText.setFillColor(sf::Color::White);
            sf::FloatRect goRect = gameOverText.getLocalBounds();
            gameOverText.setOrigin({ goRect.size.x / 2, goRect.size.y / 2 });
            gameOverText.setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) / 2.f - 80 });

            sf::Text killsText(font);
            killsText.setString("Kills: " + std::to_string(totalKills));
            killsText.setCharacterSize(40);
            killsText.setFillColor(sf::Color::White);
            sf::FloatRect kRect = killsText.getLocalBounds();
            killsText.setOrigin({ kRect.size.x / 2, kRect.size.y / 2 });
            killsText.setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) / 2.f });

            sf::Text pressKeyText(font);
            pressKeyText.setString("Press any key to continue");
            pressKeyText.setCharacterSize(30);
            pressKeyText.setFillColor(sf::Color(200, 200, 200));
            sf::FloatRect pkRect = pressKeyText.getLocalBounds();
            pressKeyText.setOrigin({ pkRect.size.x / 2, pkRect.size.y / 2 });
            pressKeyText.setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) / 2.f + 80 });

            player->resetAnimation();
            player->animateDeath();
            player->getSprite().setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) - 200.f });

            window.clear(sf::Color::Black);

            window.draw(gameOverText);
            window.draw(killsText);
            window.draw(pressKeyText);
            window.draw(player->getSprite());
            window.display();

            bool wait = true;
            while (wait && window.isOpen()) {
                while (const std::optional<sf::Event> event = window.pollEvent()) {

                    if (event->is<sf::Event::Closed>()) {
                        window.close();
                        return;
                    }
                    if (event->is<sf::Event::KeyPressed>() || event->is<sf::Event::MouseButtonPressed>())
                    {
                        wait = false;
                    }
                }

            }
            return;
        }

        // Spawn next wave if all mobs are dead
        if (mobs.empty() && !waitingForNextWave) {
            waitingForNextWave = true;
            waveDelayClock.restart();
        }

        if (waitingForNextWave && waveDelayClock.getElapsedTime().asSeconds() >= waveDelaySeconds) {
            ++waveNumber;
            numberOfMobs += 5;

            if (waveNumber % 5 == 0) {

                mobs.clear();

                std::unique_ptr<Mob> boss = std::make_unique<Boss>();
                boss->getSprite().setPosition({ static_cast<float>(window.getSize().x) / 2.f, static_cast<float>(window.getSize().y) / 2.f });
                boss->resetAnimation();
                boss->animateAttack();
                mobs.push_back(std::move(boss));
                showWaveText = true;
                incrementGearValue();
                ensureGearFileExistsAndValid();

                waveText.setString("BOSS WAVE!");
                waveTextClock.restart();
            }
            else {
                spawnWave(mobs, numberOfMobs, waveTextClock, showWaveText, window);
            }
            waitingForNextWave = false;
        }

        // Calculate HP level and update the HP bar
        int hpLevel = calculateHpLevel(currentHp, maxHP, totalLevels);
        updateHpBar(hpBarSprite, hpLevel, frameWidth, frameHeight);

        // Calculate EXP progress ratio (kills / killsNeededForNextLevel)
        float expRatio = static_cast<float>(kills) / static_cast<float>(killsNeededForNextLevel);
        if (expRatio > 1.f) expRatio = 1.f;

        // Mob behavior and animation updates
        for (auto& mob : mobs) {
            float distance = mob->chase(player->getSprite());
            if (distance <= 35.f && mob->getHp() != 0) {
                // Trigger attack animation
                if (!mob->isAnimationFinished()) {
                    mob->animateAttack();
                }
                // Apply damage once attack animation finishes
                if (mob->isAnimationFinished() && !mob->hasAttacked) {
                    currentHp -= mob->getAttack();
                    mob->hasAttacked = true;
                    std::cout << "HP: " << currentHp << std::endl;
                }
            }
            if (mob->getHp() != 0) {
                mob->resetAnimation();
            }
        }

        // Update mob list, check for kills and handle level-ups
        updateMobs(mobs, totalKills, kills, killsNeededForNextLevel, player, levelText, maxHP, bombDamage, currentHp, bonusMessage, showBonus, bonusClock);

        // Draw mobs
        for (auto& mob : mobs) {
            window.draw(mob->getSprite());
        }

        // Draw player
        window.draw(player->getSprite());

        // Update and draw bombs
        float bombClock = clock.restart().asSeconds();
        drawBombs(window, activeBombs, bombTexture, bombClock);

        // Draw UI elements: level text, EXP bar, and HP bar
        drawLevelText(window, levelText, centerX, expBarPosY);
        drawExpBar(window, expBarBack, expBarFront, expBarWidth, expRatio);

        window.draw(backBar);
        window.draw(hpBarSprite);

        // Show wave text with fading
        if (showWaveText) {
            drawWaveText(window, waveText, waveNumber, waveTextClock, showWaveText, 2.0f, 1.0f);
        }

        if (showBonus) {
            bonusText.setString(bonusMessage);
            bonusText.setOrigin({ bonusText.getLocalBounds().size.x / 2.f, 0 });
            window.draw(bonusText);
            if (bonusClock.getElapsedTime().asSeconds() > 2.0f) {
                showBonus = false;
            }
        }

        window.draw(hpText);
        window.draw(mouseTimerText);

        window.display();
    }
}
