#include "Classes.h"

Mob::Mob(const sf::Texture& texture) : sprite(texture){
    sprite.setOrigin({
        sprite.getLocalBounds().size.x / 2.f,
        sprite.getLocalBounds().size.y / 2.f
        });
}

float Mob::getHp() const {
    return this->hp;
}
float Mob::getAttack() const {
    return this->attack;
}

void Mob::animate(int frames) {
    frameDuration = sf::milliseconds(100);
    totalFrames = frames;

    if (animationFinished) return;

    if (frameClock.getElapsedTime() >= frameDuration) {
        int frameHeight = 150;
        int frameWidth = 150;
        sprite.setTextureRect({ {currentFrame * frameWidth, 0}, {frameWidth, frameHeight} });
        currentFrame++;
        if (currentFrame >= totalFrames) {
            currentFrame = totalFrames - 1; // stay on last frame
            animationFinished = true;
        }
        frameClock.restart();
    }
}
void Mob::flipSprite(sf::Vector2f direction) {
    sprite.setScale({ direction.x < 0 ? -1.f : 1.f, 1.f });
}
bool Mob::isAnimationFinished() const {
    return animationFinished;
}
void Mob::resetAnimation() {
    if (animationFinished && resetDelayClock.getElapsedTime() >= frameDuration * static_cast<float>(totalFrames)) {

        currentFrame = 0;
        animationFinished = false;
        frameClock.restart();
        resetDelayClock.restart();

        hasAttacked = false;
    }
}

//Loading a texture for the mobs or creating a new one if the loading fails
sf::Texture Mob::loadTexture(const std::string& fileName) {
    sf::Texture texture;
    std::string filePath = folder + fileName;
    if (!texture.loadFromFile(filePath)) {
        std::cerr << "Failed to load: " << filePath << '\n';
        texture = createTexture(150, 150);
    }
    return texture;
}

float Mob::chase(const sf::Sprite& target) {
    float deltaTime = moveClock.restart().asSeconds();

    sf::Vector2f mobPos = sprite.getPosition();
    sf::Vector2f targetPos = target.getPosition();

    sf::Vector2f direction = targetPos - mobPos;
    float distance = std::sqrt(direction.x * direction.x + direction.y * direction.y);

    if (distance != 0)
        direction /= distance;

    float moveSpeed = 250.f * speed;
    sf::Vector2f movement = direction * moveSpeed * deltaTime;

    if (distance > 35.f) {
        sprite.move(movement);
        animateMove();
        sprite.setOrigin({ 75.f, 75.f });
        flipSprite(direction);
    }
    else {
        sprite.setOrigin({ 75.f, 75.f });
    }

    return distance;
}

void Mob::animateAttack() {
    int frames = 8;
    texture = loadTexture("Attack.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
void Mob::animateDeath() {
    int frames = 4;
    texture = loadTexture("Death.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
void Mob::animateMove() {
    int frames = 8;
    texture = loadTexture("Run.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
void Mob::animateTakeHit() {
    int frames = 4;
    texture = loadTexture("Take Hit.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
void Mob::animateIdle() {
    int frames = 4;
    texture = loadTexture("Idle.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
void Mob::animateShield() {
    int frames = 4;
    texture = loadTexture("Shield.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
sf::Sprite& Mob::getSprite() {
    return this->sprite;
}
float Mob::setHp(float hp) {
    this->hp = hp;
    return this->hp; // Return the updated hp value
}


FlyingEye::FlyingEye() : Mob(sf::Texture()) {
    folder += "Flying eye/";
    attack = 2;
    hp = 10;
    speed = 1.2;
}
void FlyingEye::animateMove() {
    int frames = 8;
    texture = loadTexture("Flight.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(150, 150)) {
        frames = 0;
    }
    animate(frames);
}
void FlyingEye::animateIdle() {
}
void FlyingEye::animateShield() {
}

Goblin::Goblin() : Mob(sf::Texture()) {
    folder += "Goblin/";
    attack = 5;
    hp = 20;
    speed = 1.15;
}
void Goblin::animateShield() {
}

Mushroom::Mushroom() : Mob(sf::Texture()) {
    folder += "Mushroom/";
    attack = 10;
    hp = 30;
    speed = 0.75;
}
void Mushroom::animateShield() {
}

Skeleton::Skeleton() : Mob(sf::Texture()) {
    folder += "Skeleton/";
    attack = 10;
    hp = 70;
    speed = 0.9;
}
void Skeleton::animateMove() {
    int frames = 4;
    texture = loadTexture("Run.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(288, 160)) {
        frames = 0;
    }
    animate(frames);
}

Boss::Boss() : Mob(sf::Texture()) {
    sprite.setOrigin({
       sprite.getLocalBounds().size.x / 2.f,
       sprite.getLocalBounds().size.y / 2.f
        });
    folder += "Boss/";
    attack = 50;
    hp = 3000;
    speed = 0.5;
}
void Boss::animate(int frames) {
    int totalFrames = frames;
    sf::Time frameDuration = sf::milliseconds(100);

    if (animationFinished) return;

    if (frameClock.getElapsedTime() >= frameDuration) {
        int frameHeight = 160;
        int frameWidth = 288;
        sprite.setTextureRect({ {currentFrame * frameWidth, 0}, {frameWidth, frameHeight} });
        currentFrame++;
        if (currentFrame >= totalFrames) {
            currentFrame = totalFrames - 1; // stay on last frame
            animationFinished = true;
        }
        frameClock.restart();
    }
}
void Boss::flipSprite(sf::Vector2f direction) {
    sprite.setOrigin({
        sprite.getLocalBounds().size.x / 2.f,
        sprite.getLocalBounds().size.y / 2.f
        });
    sprite.setScale({ direction.x < 0 ? 2.f : -2.f, 2.f });
}
void Boss::animateAttack() {
    int frames = 15;
    texture = loadTexture("Attack.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(288, 160)) {
        frames = 0;
    }
    animate(frames);
}
void Boss::animateDeath() {
    int frames = 22;
    texture = loadTexture("Death.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(288, 160)) {
        frames = 0;
    }
    animate(frames);
}
void Boss::animateMove() {
    int frames = 12;
    texture = loadTexture("Move.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(288, 160)) {
        frames = 0;
    }
    animate(frames);
}
void Boss::animateIdle() {
    int frames = 6;
    texture = loadTexture("Idle.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(288, 160)) {
        frames = 0;
    }
    animate(frames);
}
void Boss::animateTakeHit() {
    int frames = 5;
    texture = loadTexture("Take Hit.png");
    sprite.setTexture(texture);
    if (sprite.getTexture().getSize() == sf::Vector2u(288, 160)) {
        frames = 0;
    }
    animate(frames);
}
