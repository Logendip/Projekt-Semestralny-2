#ifndef CLASSES_H
#define CLASSES_H

#pragma once
#include <iostream>
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <utility>
#include <vector>
#include <random>
#include <cmath>
#include <fstream>
#include <sstream>
#include <string>
#include <map>

// External resources
inline sf::Font font;
inline sf::Music backgroundMusic;
inline sf::Texture backgroundTexture;
void loadAssets();
sf::Texture createTexture(int x, int y);

class Character {
protected:
    float attack;
    float defense;
    float hp;
    float speed;
    unsigned level;
    std::string folder;
    sf::Sprite sprite;
    sf::Texture texture;

    // Animation members
    int currentFrame = 0;
    sf::Clock frameClock;
    bool animationFinished = false;
    sf::Clock resetDelayClock;
    float resetDelay = 1.0f; // seconds

    sf::Clock moveClock;

public:
    // Input state
    bool movingUp = false;
    bool movingDown = false;
    bool movingLeft = false;
    bool movingRight = false;
    explicit Character();

    // Setters
    void setAttack(float attack);
    void setDef(float defense);
    void setHp(float hp);
    void setSpeed(float speed);
    void setLevel(unsigned level);
    void setFolder(std::string folder);
    void setSprite(sf::Sprite& newSprite);

    // Getters
    [[nodiscard]] float getAttack() const;
    [[nodiscard]] float getHp() const;
    [[nodiscard]] float getDef() const;
    [[nodiscard]] float getSpeed() const;
    [[nodiscard]] unsigned getLevel() const;
    std::string getFolder();
    sf::Sprite& getSprite();

    // Animation
    void animateAttack();
    void animateDeath();
    void animateIdle();
    void animateMove();
    void animate(int frames);
    void resetAnimation();
    bool isAnimationFinished() const;
    void handleEvent(const sf::Event& event);
    void move(sf::Window& window);

    sf::Texture loadTexture(const std::string& fileName);
};

class Mob {
protected:
    float attack = 10;
    float hp = 300;
    float speed = 1;

    sf::Sprite sprite;
    sf::Texture texture;
    std::string folder = "assets/Mobs/";

    int currentFrame = 0;
    sf::Clock frameClock;
    bool animationFinished = false;
    int totalFrames = 0;
    sf::Time frameDuration = sf::milliseconds(100);
    sf::Clock moveClock; //Movement clock

    sf::Clock resetDelayClock;  // Track time since the last reset
    float resetDelay = 1.0f;    // Delay before resetting the animation (in seconds)
public:
    bool hasAttacked = false;
    float chase(const sf::Sprite& target);
    explicit Mob(const sf::Texture& texture);
    virtual ~Mob() = default;
    float getHp() const;
    float getAttack() const;
    float setHp(float hp);

    virtual void animate(int frames);
    virtual void flipSprite(sf::Vector2f direction);
    virtual sf::Texture loadTexture(const std::string& fileName);
    virtual void animateAttack();
    virtual void animateDeath();
    virtual void animateMove();
    virtual void animateTakeHit();
    virtual void animateIdle();
    virtual void animateShield();
    sf::Sprite& getSprite();
    void resetAnimation();
    bool isAnimationFinished() const;
};

class FlyingEye : public Mob {
public:
    FlyingEye();
    void animateMove() override;
    void animateIdle() override;
    void animateShield() override;
};
//Goblin class
class Goblin : public Mob {
public:
    Goblin();
    void animateShield() override;
};
//Mushroom class
class Mushroom : public Mob {
public:
    Mushroom();
    void animateShield() override;
};
//Skeleton class
class Skeleton : public Mob {
public:
    Skeleton();
    void animateMove() override;
};
//Boss class
class Boss : public Mob {
public:
    Boss();
    void animate(int frames) override;
    void animateMove() override;
    void animateIdle() override;
    void animateAttack() override;
    void animateDeath() override;
    void animateTakeHit() override;
    void flipSprite(sf::Vector2f direction) override;
};

class Game {
private:
    sf::RenderWindow window;
    Character player;
public:
    explicit Game();
    sf::RenderWindow& getWindow();
    void run();
};

#endif //CLASSES_H
