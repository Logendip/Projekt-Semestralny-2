#ifndef WAVES_H
#define WAVES_H
#pragma once

#include "Classes.h"
#include "Menu.h"

void waves(sf::RenderWindow& window, Character* player);

#endif //WAVES_H
